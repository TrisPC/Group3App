package com.example.myapplication;

public class global
{
    String username = "";
    String uid = "";
    String token = "";
}
